import React from 'react';
import '../styles/BoardPage.css';

function BoardPage() {
  const boardMembers = [
    {
      id: 1,
      name: 'Emma Johnson',
      position: 'President',
      bio: 'Emma is a senior who has been with SADD for three years. She is passionate about promoting safe driving habits and creating awareness campaigns.',
      image: 'https://randomuser.me/api/portraits/women/1.jpg'
    },
    {
      id: 2,
      name: 'Michael Chen',
      position: 'Vice President',
      bio: 'Michael joined SADD in his sophomore year and has been instrumental in organizing community outreach programs and school assemblies.',
      image: 'https://randomuser.me/api/portraits/men/2.jpg'
    },
    {
      id: 3,
      name: 'Sophia Rodriguez',
      position: 'Secretary',
      bio: 'Sophia is responsible for coordinating club meetings and maintaining records. She is dedicated to creating a supportive environment for all members.',
      image: 'https://randomuser.me/api/portraits/women/3.jpg'
    },
    {
      id: 4,
      name: 'David Kim',
      position: 'Treasurer',
      bio: 'David manages the club\'s finances and fundraising efforts. He is committed to ensuring the club has the resources needed for its initiatives.',
      image: 'https://randomuser.me/api/portraits/men/4.jpg'
    },
    {
      id: 5,
      name: 'Olivia Patel',
      position: 'Social Media Coordinator',
      bio: 'Olivia handles all social media accounts and digital communications. She is creative and passionate about spreading the SADD message online.',
      image: 'https://randomuser.me/api/portraits/women/5.jpg'
    },
    {
      id: 6,
      name: 'James Wilson',
      position: 'Events Coordinator',
      bio: 'James plans and organizes all SADD events throughout the school year. He is known for his innovative ideas and attention to detail.',
      image: 'https://randomuser.me/api/portraits/men/6.jpg'
    }
  ];

  return (
    <>
      <div className="board-header">
        <div className="container">
          <h1 className="board-title">Meet Our Board</h1>
          <p className="board-subtitle">The dedicated team leading GNS SADD Club</p>
        </div>
      </div>

      <div className="container">
        <section className="section">
          <div className="board-intro">
            <p>
              Our board members are dedicated students who are passionate about promoting positive decision-making and creating a safer school environment. They work tirelessly to organize events, workshops, and awareness campaigns throughout the school year.
            </p>
          </div>

          <div className="board-members">
            {boardMembers.map(member => (
              <div className="member-card" key={member.id}>
                <div className="member-image">
                  <img src={member.image} alt={member.name} />
                </div>
                <div className="member-info">
                  <h3 className="member-name">{member.name}</h3>
                  <h4 className="member-position">{member.position}</h4>
                  <p className="member-bio">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="section join-board-section">
          <h2 className="section-title">Interested in Joining the Board?</h2>
          <div className="join-board-content">
            <p>
              Board elections are held at the end of each school year. If you're interested in taking on a leadership role in the SADD Club, attend our meetings regularly and express your interest to the current board members.
            </p>
            <p>
              Leadership positions are a great way to make a difference in our school community while developing valuable skills that will benefit you in college and beyond.
            </p>
            <a href="#" className="btn">Learn About Elections</a>
          </div>
        </section>
      </div>
    </>
  );
}

export default BoardPage;
